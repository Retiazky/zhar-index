export enum ChallengeStatus {
    Active = "Active",
    ProofSubmitted = "ProofSubmitted",
    Completed = "Completed",
    Expired = "Expired",
    Failed = "Failed",
}
